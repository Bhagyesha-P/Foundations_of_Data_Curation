# A Study of Impulsivity and Adverse Childhood Experiences in a Population Health Setting

## Description of the data and file structure

This file contains 17,479 participants with columns representing age at consent stratified into 5 year age ranges, sex, BIS (Barratt Impulsivity Scale)-15 score, and the number of Aces (Adverse Childhood Experiences). 

For sex, females are 0 and males are coded as 1. 
